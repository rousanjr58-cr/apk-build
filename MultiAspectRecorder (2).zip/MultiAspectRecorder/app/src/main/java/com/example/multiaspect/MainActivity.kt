package com.example.multiaspect

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.effect.Crop
import androidx.media3.effect.MatrixTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors

private const val RED = 0xFFFF5A5F.toInt()
private const val GREEN = 0xFF00E676.toInt()

data class Fmt(val label: String, val name: String, val ratio: Float)
data class TrackBox(val id: Int?, val l: Float, val t: Float, val r: Float, val b: Float)

/** Dims outside the chosen ratio, draws the red crop guide and tracked-object boxes. */
class FrameOverlay(ctx: Context) : View(ctx) {
    private var ratio = 16f / 9f
    private var label = "16:9"
    private var boxes: List<TrackBox> = emptyList()
    private var lockedId: Int? = null
    private var trackY = 0.5f

    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = RED; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = RED; textSize = 36f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val lockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREEN; style = Paint.Style.STROKE; strokeWidth = 7f
    }
    private val lockText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREEN; textSize = 34f; typeface = Typeface.DEFAULT_BOLD
    }

    fun setFormat(label: String, ratio: Float) {
        this.label = label; this.ratio = ratio; invalidate()
    }

    fun setTracking(boxes: List<TrackBox>, lockedId: Int?, trackY: Float) {
        this.boxes = boxes; this.lockedId = lockedId; this.trackY = trackY; invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        var bw = w; var bh = w / ratio
        if (bh > h) { bh = h; bw = h * ratio }
        val cy = if (lockedId != null) (trackY * h).coerceIn(bh / 2f, h - bh / 2f) else h / 2f
        val r = RectF((w - bw) / 2f, cy - bh / 2f, (w + bw) / 2f, cy + bh / 2f)

        c.drawRect(0f, 0f, w, r.top, dim)
        c.drawRect(0f, r.bottom, w, h, dim)
        c.drawRect(0f, r.top, r.left, r.bottom, dim)
        c.drawRect(r.right, r.top, w, r.bottom, dim)
        c.drawRect(r, guide)
        c.drawText(label, r.centerX(), r.top + 56f, text)

        for (b in boxes) {
            val rect = RectF(b.l * w, b.t * h, b.r * w, b.b * h)
            if (b.id != null && b.id == lockedId) {
                c.drawRect(rect, lockPaint)
                c.drawText("TRACKING", rect.left + 8f, rect.top - 10f, lockText)
            } else c.drawRect(rect, boxPaint)
        }
    }
}

class RecordButton(ctx: Context) : View(ctx) {
    var recording = false
        set(v) { field = v; invalidate() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 10f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF3B30.toInt() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        c.drawCircle(cx, cy, r - 6f, ring)
        if (recording) {
            val s = r * 0.40f
            c.drawRoundRect(cx - s, cy - s, cx + s, cy + s, 16f, 16f, fill)
        } else {
            c.drawCircle(cx, cy, r * 0.72f, fill)
        }
    }
}

class MainActivity : AppCompatActivity() {

    private val formats = listOf(
        Fmt("16:9", "Landscape", 16f / 9f),
        Fmt("1:1", "Square", 1f),
        Fmt("3:4", "Classic", 3f / 4f),
        Fmt("4:3", "Standard", 4f / 3f),
        Fmt("4:5", "Vertical", 4f / 5f)
    )
    private var selected = 0

    private lateinit var previewView: PreviewView
    private lateinit var overlay: FrameOverlay
    private lateinit var countdownText: TextView
    private lateinit var timeText: TextView
    private lateinit var flashBtn: TextView
    private lateinit var trackBtn: TextView
    private lateinit var stabBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var flipBtn: TextView
    private lateinit var recordBtn: RecordButton
    private val cards = mutableListOf<LinearLayout>()
    private val icons = mutableListOf<View>()

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var torchOn = false
    private var transformer: Transformer? = null

    // Stabilizer
    private var stabEnabled = true
    private var stabActive = false
    private var stabSupported = false

    // Object tracking
    private var trackingOn = false
    private var trackingAvailable = true
    private var lockedId: Int? = null
    private var targetY = 0.5f
    private var lastBoxes: List<TrackBox> = emptyList()
    private val pathT = ArrayList<Long>()
    private val pathY = ArrayList<Float>()
    private var recStartNs = 0L
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val detector by lazy {
        ObjectDetection.getClient(
            ObjectDetectorOptions.Builder()
                .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                .enableMultipleObjects()
                .build()
        )
    }

    // Timer
    private val timerOptions = listOf(0, 3, 10)
    private var timerIdx = 0
    private val handler = Handler(Looper.getMainLooper())
    private var countdownLeft = 0
    private val tick = object : Runnable {
        override fun run() {
            countdownLeft--
            if (countdownLeft <= 0) {
                countdownText.visibility = View.GONE
                startRecording()
            } else {
                countdownText.text = countdownLeft.toString()
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            if (r.values.all { it }) startCamera()
            else toast("Camera and microphone permissions are required")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (needed.all { has(it) }) startCamera() else permissionLauncher.launch(needed)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(tick)
        analysisExecutor.shutdown()
        detector.close()
    }

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------------- UI ----------------
    private fun pill(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat(); setColor(0xFF1C1C1E.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun spacer() = View(this)

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val screenW = resources.displayMetrics.widthPixels
        val frameH = screenW * 16 / 9
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val frame = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        overlay = FrameOverlay(this)
        countdownText = TextView(this).apply {
            textSize = 96f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            visibility = View.GONE
        }
        frame.addView(previewView, FrameLayout.LayoutParams(match, match))
        frame.addView(overlay, FrameLayout.LayoutParams(match, match))
        frame.addView(countdownText, FrameLayout.LayoutParams(match, match))
        root.addView(frame, FrameLayout.LayoutParams(screenW, frameH, Gravity.TOP))

        // Tap an object to lock tracking onto it; tap empty space to release.
        overlay.setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP && trackingOn) {
                val nx = ev.x / v.width
                val ny = ev.y / v.height
                val hit = lastBoxes
                    .filter { it.id != null && nx in it.l..it.r && ny in it.t..it.b }
                    .minByOrNull { (it.r - it.l) * (it.b - it.t) }
                if (hit != null) {
                    lockedId = hit.id
                    targetY = (hit.t + hit.b) / 2f
                } else {
                    lockedId = null
                    targetY = 0.5f
                }
                overlay.setTracking(lastBoxes, lockedId, targetY)
            }
            true
        }

        // Top bar: Track | Stab | Flash
        trackBtn = pill("🎯 Track Off") { toggleTracking() }
        stabBtn = pill("🎥 Stab On") { toggleStab() }
        flashBtn = pill("⚡ Off") { toggleTorch() }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(40), dp(14), 0)
        }
        top.addView(trackBtn)
        top.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(stabBtn)
        top.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(flashBtn)
        root.addView(top, FrameLayout.LayoutParams(match, wrap, Gravity.TOP))

        timeText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            visibility = View.GONE
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat(); setColor(0xFFD32F2F.toInt())
            }
        }
        root.addView(timeText, FrameLayout.LayoutParams(wrap, wrap,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(100) })

        // Bottom panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(22))
            val r = dp(26).toFloat()
            background = GradientDrawable().apply {
                setColor(0xEB0B0B12.toInt()); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        panel.addView(TextView(this).apply {
            text = "ⓘ  Records portrait by default, plus a cropped copy in the format you choose."
            setTextColor(0xFFFFD54F.toInt()); textSize = 13f
            setPadding(dp(8), 0, dp(8), dp(10))
        })

        val ratioRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        formats.forEachIndexed { i, f ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { select(i) }
            }
            val box = dp(38)
            val iw = if (f.ratio >= 1f) box else (box * f.ratio).toInt()
            val ih = if (f.ratio >= 1f) (box / f.ratio).toInt() else box
            val icon = View(this)
            val holder = FrameLayout(this)
            holder.addView(icon, FrameLayout.LayoutParams(iw, ih, Gravity.CENTER))
            card.addView(holder, LinearLayout.LayoutParams(match, dp(44)))
            card.addView(TextView(this).apply {
                text = f.label; setTextColor(Color.WHITE); textSize = 17f
                typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            })
            card.addView(TextView(this).apply {
                text = f.name; setTextColor(0xFFB0B0B8.toInt()); textSize = 11f
                gravity = Gravity.CENTER
            })
            cards += card; icons += icon
            ratioRow.addView(card, LinearLayout.LayoutParams(0, wrap, 1f)
                .apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        panel.addView(ratioRow)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(16), dp(8), 0)
        }
        timerBtn = pill("⏱ Off") { cycleTimer() }
        flipBtn = pill("🔄 Flip") { flipCamera() }
        recordBtn = RecordButton(this).apply { setOnClickListener { onRecordClick() } }
        bottom.addView(timerBtn)
        bottom.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        bottom.addView(recordBtn, LinearLayout.LayoutParams(dp(78), dp(78)))
        bottom.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        bottom.addView(flipBtn)
        panel.addView(bottom)

        root.addView(panel, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM))
        setContentView(root)
        select(0)
    }

    private fun select(i: Int) {
        if (recording != null) return
        selected = i
        overlay.setFormat(formats[i].label, formats[i].ratio)
        styleCards()
    }

    private fun styleCards() {
        val busy = recording != null
        cards.forEachIndexed { i, c ->
            val sel = i == selected
            c.background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(if (sel) 0xFF2A0808.toInt() else Color.TRANSPARENT)
                setStroke(dp(1), if (sel) RED else Color.TRANSPARENT)
            }
            icons[i].background = GradientDrawable().apply {
                cornerRadius = dp(4).toFloat()
                setColor(if (sel) 0xFF5A1A1A.toInt() else 0xFF2C2C2E.toInt())
                setStroke(dp(2), if (sel) RED else Color.WHITE)
            }
            c.alpha = if (busy) 0.4f else 1f
        }
    }

    // ---------------- Controls ----------------
    private fun toggleTorch() {
        val cam = camera
        if (cam != null && cam.cameraInfo.hasFlashUnit()) {
            torchOn = !torchOn
            cam.cameraControl.enableTorch(torchOn)
            flashBtn.text = if (torchOn) "⚡ On" else "⚡ Off"
        } else toast("Flash not available on this camera")
    }

    private fun toggleStab() {
        if (recording != null) { toast("Stop recording to change stabilizer"); return }
        stabEnabled = !stabEnabled
        bindCamera()
        if (stabEnabled && !stabActive) toast("Stabilization isn't supported on this camera")
    }

    private fun updateStabLabel() {
        stabBtn.text = when {
            stabActive -> "🎥 Stab On"
            stabEnabled && !stabSupported -> "🎥 Stab N/A"
            else -> "🎥 Stab Off"
        }
    }

    private fun toggleTracking() {
        if (!trackingAvailable) { toast("Object tracking isn't supported with this camera setup"); return }
        trackingOn = !trackingOn
        trackBtn.text = if (trackingOn) "🎯 Track On" else "🎯 Track Off"
        if (trackingOn) toast("Tap an object to lock on. Tap empty space to release.")
        else {
            lockedId = null; targetY = 0.5f; lastBoxes = emptyList()
            overlay.setTracking(emptyList(), null, 0.5f)
        }
    }

    private fun cycleTimer() {
        timerIdx = (timerIdx + 1) % timerOptions.size
        val s = timerOptions[timerIdx]
        timerBtn.text = if (s == 0) "⏱ Off" else "⏱ ${s}s"
    }

    private fun flipCamera() {
        if (recording != null) return
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        torchOn = false
        flashBtn.text = "⚡ Off"
        lockedId = null; targetY = 0.5f; lastBoxes = emptyList()
        overlay.setTracking(emptyList(), null, 0.5f)
        bindCamera()
    }

    private fun onRecordClick() {
        if (recording != null) { recording?.stop(); return }
        if (countdownLeft > 0) { cancelCountdown(); return }
        val s = timerOptions[timerIdx]
        if (s > 0) {
            countdownLeft = s
            countdownText.text = s.toString()
            countdownText.visibility = View.VISIBLE
            handler.postDelayed(tick, 1000)
        } else startRecording()
    }

    private fun cancelCountdown() {
        handler.removeCallbacks(tick)
        countdownLeft = 0
        countdownText.visibility = View.GONE
    }

    // ---------------- Camera ----------------
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({ provider = f.get(); bindCamera() }, ContextCompat.getMainExecutor(this))
    }

    private fun stabSupportedBy(info: CameraInfo): Boolean = try {
        val c2 = Camera2CameraInfo.from(info)
        val vs = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        val ois = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        (vs?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) ||
            (ois?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true)
    } catch (e: Exception) { false }

    private fun buildUseCases(stab: Boolean, analysis: Boolean, info: CameraInfo?): List<UseCase> {
        val preview = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9).build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }
        val recorder = Recorder.Builder()
            .setAspectRatio(AspectRatio.RATIO_16_9)
            .setQualitySelector(QualitySelector.from(
                Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
            .build()
        val vb = VideoCapture.Builder(recorder)

        if (stab && info != null) {
            val c2 = Camera2CameraInfo.from(info)
            val ext = Camera2Interop.Extender(vb)
            val vs = c2.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            if (vs?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) {
                ext.setCaptureRequestOption(
                    CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                    CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON)
            }
            val ois = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            if (ois?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true) {
                ext.setCaptureRequestOption(
                    CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                    CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)
            }
        }
        val vc = vb.build()
        videoCapture = vc

        val list = mutableListOf<UseCase>(preview, vc)
        if (analysis) {
            val ia = ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            ia.setAnalyzer(analysisExecutor) { proxy -> analyze(proxy) }
            list += ia
        }
        return list
    }

    private fun bindCamera() {
        val p = provider ?: return
        if (recording != null) return
        val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val info = try { selector.filter(p.availableCameraInfos).firstOrNull() } catch (e: Exception) { null }
        stabSupported = info != null && stabSupportedBy(info)

        // Try the richest setup first, then fall back so the camera always opens.
        val attempts = mutableListOf<Pair<Boolean, Boolean>>()
        if (stabEnabled && stabSupported) attempts += (true to true)
        attempts += (false to true)
        attempts += (false to false)

        var lastErr: Exception? = null
        for ((stab, analysis) in attempts) {
            try {
                val cases = buildUseCases(stab, analysis, info)
                p.unbindAll()
                camera = p.bindToLifecycle(this, selector, *cases.toTypedArray())
                stabActive = stab
                trackingAvailable = analysis
                updateStabLabel()
                return
            } catch (e: Exception) { lastErr = e }
        }
        toast("Camera failed: ${lastErr?.message}")
    }

    // ---------------- Object tracking ----------------
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image
        if (!trackingOn || media == null) { proxy.close(); return }
        val rot = proxy.imageInfo.rotationDegrees
        val iw = if (rot % 180 == 0) proxy.width else proxy.height
        val ih = if (rot % 180 == 0) proxy.height else proxy.width
        val input = InputImage.fromMediaImage(media, rot)
        detector.process(input)
            .addOnSuccessListener { objs -> handleObjects(objs, iw, ih) }
            .addOnCompleteListener { proxy.close() }
    }

    private fun handleObjects(objs: List<DetectedObject>, iw: Int, ih: Int) {
        if (!trackingOn) return
        val front = lensFacing == CameraSelector.LENS_FACING_FRONT
        val boxes = objs.map { o ->
            val b = o.boundingBox
            var l = b.left / iw.toFloat()
            var r = b.right / iw.toFloat()
            if (front) { val nl = 1f - r; r = 1f - l; l = nl }
            TrackBox(o.trackingId, l, b.top / ih.toFloat(), r, b.bottom / ih.toFloat())
        }
        lastBoxes = boxes
        val id = lockedId
        if (id != null) {
            boxes.firstOrNull { it.id == id }?.let {
                targetY = 0.7f * targetY + 0.3f * ((it.t + it.b) / 2f)
            }
            if (recording != null) {
                pathT += (SystemClock.elapsedRealtimeNanos() - recStartNs) / 1000L
                pathY += targetY
            }
        }
        overlay.setTracking(boxes, id, targetY)
    }

    // ---------------- Recording ----------------
    private fun startRecording() {
        val vc = videoCapture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val fmt = formats[selected]
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_${stamp}_portrait")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MultiAspect")
        }
        val out = MediaStoreOutputOptions
            .Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()

        pathT.clear(); pathY.clear()
        recording = vc.output.prepareRecording(this, out)
            .apply { if (has(Manifest.permission.RECORD_AUDIO)) withAudioEnabled() }
            .start(ContextCompat.getMainExecutor(this)) { e ->
                when (e) {
                    is VideoRecordEvent.Start -> {
                        recStartNs = SystemClock.elapsedRealtimeNanos()
                        setRecordingUi(true)
                    }
                    is VideoRecordEvent.Status -> {
                        val s = e.recordingStats.recordedDurationNanos / 1_000_000_000L
                        timeText.text = "● %02d:%02d".format(s / 60, s % 60)
                    }
                    is VideoRecordEvent.Finalize -> {
                        recording = null
                        setRecordingUi(false)
                        if (e.hasError()) toast("Recording failed (${e.error})")
                        else {
                            toast("Portrait saved. Creating ${fmt.label} copy…")
                            cropAndSave(e.outputResults.outputUri, fmt, stamp,
                                pathT.toLongArray(), pathY.toFloatArray())
                        }
                    }
                    else -> Unit
                }
            }
    }

    private fun setRecordingUi(on: Boolean) {
        recordBtn.recording = on
        timeText.visibility = if (on) View.VISIBLE else View.GONE
        flipBtn.alpha = if (on) 0.4f else 1f
        stabBtn.alpha = if (on) 0.4f else 1f
        styleCards()
    }

    // ---------------- Crop (follows tracked object if locked) ----------------
    private fun frameRatio(uri: Uri): Float {
        val m = MediaMetadataRetriever()
        return try {
            m.setDataSource(this, uri)
            var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toFloat()
            var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toFloat()
            val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            w / h
        } catch (e: Exception) { 9f / 16f } finally { m.release() }
    }

    private fun interpolate(tUs: LongArray, y: FloatArray, us: Long): Float {
        if (us <= tUs.first()) return y.first()
        if (us >= tUs.last()) return y.last()
        var i = 0
        while (i < tUs.size - 1 && tUs[i + 1] < us) i++
        val span = (tUs[i + 1] - tUs[i]).coerceAtLeast(1L).toFloat()
        val a = (us - tUs[i]) / span
        return y[i] + (y[i + 1] - y[i]) * a
    }

    private fun cropAndSave(source: Uri, fmt: Fmt, stamp: String, pt: LongArray, py: FloatArray) {
        val fr = frameRatio(source)
        val r = fmt.ratio
        val effects = ArrayList<androidx.media3.common.Effect>()
        val crop: Crop
        if (r >= fr) {
            val f = fr / r                       // keep full width, trim top and bottom
            if (pt.size >= 2) {
                val lim = 1f - f
                effects += MatrixTransformation { us ->
                    val yN = interpolate(pt, py, us)          // 0 = top, 1 = bottom
                    val c = (1f - 2f * yN).coerceIn(-lim, lim) // NDC y of the target
                    Matrix().apply { setTranslate(0f, -c) }   // slide frame so target is centered
                }
            }
            crop = Crop(-1f, 1f, -f, f)
        } else {
            val g = r / fr                       // keep full height, trim left and right
            crop = Crop(-g, g, -1f, 1f)
        }
        effects += crop

        val item = EditedMediaItem.Builder(MediaItem.fromUri(source))
            .setEffects(Effects(emptyList(), effects)).build()
        val temp = File(cacheDir, "crop_$stamp.mp4")
        val name = "VID_${stamp}_${fmt.label.replace(':', 'x')}"

        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    copyToGallery(temp, name, fmt.label)
                }
                override fun onError(
                    composition: Composition, exportResult: ExportResult,
                    exportException: ExportException
                ) { toast("Crop failed: ${exportException.message}") }
            }).build()
        transformer?.start(item, temp.absolutePath)
    }

    private fun copyToGallery(src: File, name: String, label: String) {
        Thread {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MultiAspect")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
                contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
                src.delete()
                runOnUiThread { toast("$label copy saved to Movies/MultiAspect") }
            } catch (e: Exception) {
                runOnUiThread { toast("Save failed: ${e.message}") }
            }
        }.start()
    }
}
