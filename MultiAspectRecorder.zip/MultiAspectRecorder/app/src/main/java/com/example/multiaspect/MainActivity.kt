package com.example.multiaspect

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.util.Rational
import android.view.Gravity
import android.view.Surface
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var recordButton: Button
    private val ratioButtons = mutableListOf<Button>()

    private var provider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var ratio = Rational(9, 16)

    private val ratios = listOf(
        "9:16" to Rational(9, 16),
        "1:1" to Rational(1, 1),
        "4:3" to Rational(4, 3),
        "16:9" to Rational(16, 9)
    )

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result.values.all { it }) startCamera()
            else Toast.makeText(this, "Camera and mic permissions are required", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (needed.all { has(it) }) startCamera() else permissionLauncher.launch(needed)
    }

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // ---- UI (built in code so no layout XML is needed) ----
    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        root.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, 64)
        }

        val ratioRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ratios.forEach { (label, r) ->
            val b = Button(this).apply {
                text = label
                setOnClickListener { ratio = r; bindCamera(); updateSelection() }
            }
            ratioButtons += b
            ratioRow.addView(b)
        }

        recordButton = Button(this).apply {
            text = "Record"
            setOnClickListener { toggleRecording() }
        }

        controls.addView(ratioRow)
        controls.addView(recordButton)
        root.addView(controls, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM))

        setContentView(root)
        updateSelection()
    }

    private fun updateSelection() {
        ratioButtons.forEachIndexed { i, b -> b.alpha = if (ratios[i].second == ratio) 1f else 0.5f }
    }

    // ---- Camera ----
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            previewView.post { bindCamera() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val provider = provider ?: return
        if (recording != null) return // can't change ratio mid-recording

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }
        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.FHD, androidx.camera.video.FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
            .build()
        val vc = VideoCapture.withOutput(recorder)
        videoCapture = vc

        val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
        val viewPort = ViewPort.Builder(ratio, rotation)
            .setScaleType(ViewPort.FILL_CENTER)
            .build()

        val group = UseCaseGroup.Builder()
            .setViewPort(viewPort)
            .addUseCase(preview)
            .addUseCase(vc)
            .build()

        try {
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, group)
        } catch (e: Exception) {
            Toast.makeText(this, "Camera bind failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---- Recording ----
    private fun toggleRecording() {
        val active = recording
        if (active != null) {
            active.stop()
            return
        }
        val vc = videoCapture ?: return

        val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MultiAspect")
        }
        val output = MediaStoreOutputOptions
            .Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()

        recording = vc.output.prepareRecording(this, output)
            .apply { if (has(Manifest.permission.RECORD_AUDIO)) withAudioEnabled() }
            .start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> setRecordingUi(true)
                    is VideoRecordEvent.Finalize -> {
                        recording = null
                        setRecordingUi(false)
                        val msg = if (event.hasError()) "Recording failed (${event.error})" else "Saved to Movies/MultiAspect"
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                    }
                    else -> Unit
                }
            }
    }

    private fun setRecordingUi(isRecording: Boolean) {
        recordButton.text = if (isRecording) "Stop" else "Record"
        ratioButtons.forEach { it.isEnabled = !isRecording }
    }
}
